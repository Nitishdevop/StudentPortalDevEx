﻿namespace StudentPortalDevEx.Models
{
    public class ApplicationDbContext
    {
    }
}
